OUTPUT='barra/maxPluto.svg';
STYLE='sol_diametros_svg_2.xsl';
INPUT='sol_2010.2.2.xml';

java -cp ../saxon/saxon9he.jar net.sf.saxon.Transform -t \
		  -s:../../data/$INPUT  \
		  -xsl:../../xsl/$STYLE \
          -o:../../results/$OUTPUT \
          \
          \
urlImagens="file:///Users/helder/Desktop/ExtrasXML/Exemplos/SVG/sol_2010_2.2/data/img" \
titulo="Corpos do Sistema Solar maiores que Plutão" \
planeta='1' 					\
estrela='' 					\
planetaAnao='1' 			 \
asteroide='1'				 \
satelitePlaneta='1' 			\
satelitePlanetaAnao='1' 	 \
sateliteAsteroide='1' 		 \
sateliteObjeto='1' 			 \
objeto='1'					 \
minDiametro='2300'			\
fonteAlternativa='corbel' \


