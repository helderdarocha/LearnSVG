OUTPUT='barra/objetosDistantes5.svg';
STYLE='sol_barra_orbitas_svg_2.xsl';
INPUT='sol_2010.2.2.xml';

java -cp ../saxon/saxon9he.jar net.sf.saxon.Transform -t \
		  -s:../../data/$INPUT  \
		  -xsl:../../xsl/$STYLE \
          -o:../../results/$OUTPUT \
          \
titulo="Objetos com órbitas grandes" \
planeta='1' 					\
planetaAnao='1' 			 \
asteroide='1'				 \
tno='1'					 \
cometa='1'              \
centauro='1'            \
\
minDiametro='0'			\
minOrbita='120'   \
maxOrbita='150'   \
escalaHorizontal='0.9'    \
maisX='50'   \
tamFonte="10"     \
brilhoSol='1'    \
\
linhaCentauro='0.2'   \
linhaAsteroide='0.5'   \
linhaPlaneta='1'   \
linhaPlanetaAnao='1'   \
linhaTNO='0.5'   \
linhaCometa='0.1'   \
\
circuloCentauro='1'  \
circuloAsteroide='1'  \
circuloPlaneta='2'  \
circuloPlanetaAnao='2'  \
circuloTNO='1'  \
circuloCometa='1'  \
\
mostrarNomeCentauro=''   \
mostrarNomeAsteroide='1'   \
mostrarNomePlaneta='1'   \
mostrarNomePlanetaAnao='1'   \
mostrarNomeTNO='1'   \
mostrarNomeCometa=''   \
\
segundosOrbitaMaxima='480'   \
corDeFundo='rgb(0,0,50)'    \
\
destaque="Plutão" \
textoLegendaDestaque="PLUTÃO" \




