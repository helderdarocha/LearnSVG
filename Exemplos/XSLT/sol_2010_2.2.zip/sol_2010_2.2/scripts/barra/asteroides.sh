OUTPUT='barra/asteroides.svg';
STYLE='sol_diametros_svg_2.xsl';
INPUT='sol_2010.2.2.xml';

java -cp ../saxon/saxon9he.jar net.sf.saxon.Transform -t \
		  -s:../../data/$INPUT  \
		  -xsl:../../xsl/$STYLE \
          -o:../../results/$OUTPUT \
          \
urlImagens="file:///Users/helder/Desktop/ExtrasXML/Exemplos/SVG/sol_2010_2.2/data/img" \
titulo="Cinturão de Asteroides" \
planeta='' 					\
estrela='' 					\
planetaAnao='1' 			 \
asteroide='1'				 \
cometa='1'				 \
centauro='1'				 \
satelitePlaneta='' 			\
satelitePlanetaAnao='1' 	 \
sateliteAsteroide='1' 		 \
sateliteObjeto='' 			 \
objeto=''					 \
minDiametro='180'			\
maxOrbita='10'				\
fonteAlternativa='corbel' \


