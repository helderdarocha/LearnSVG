OUTPUT='orbitas/kuiper_2.svg';
STYLE='sol_orbitas_svg_2.xsl';
INPUT='sol_2010.2.2.xml';

java -cp ../saxon/saxon9he.jar net.sf.saxon.Transform -t \
		  -s:../../data/$INPUT  \
		  -xsl:../../xsl/$STYLE \
          -o:../../results/$OUTPUT \
          \
titulo="Órbitas" \
planeta='1' 					\
planetaAnao='1' 			 \
asteroide='1'				 \
tno='1'					 \
cometa='1'              \
centauro='1'            \
\
minDiametro='0'			\
minOrbita='1.6'   \
maxOrbita='100'   \
escala='1'    \
maisX='-100'   \
maisY='0'    \
tamFonte="10"     \
brilhoSol='1'    \
\
linhaCentauro='1'   \
linhaAsteroide='1'   \
linhaPlaneta='1'   \
linhaPlanetaAnao='1'   \
linhaTNO='0.1'   \
linhaCometa='0.1'   \
\
circuloCentauro='1'  \
circuloAsteroide='1'  \
circuloPlaneta='2'  \
circuloPlanetaAnao='2'  \
circuloTNO='1'  \
circuloCometa='1'  \
\
mostrarNomeCentauro=''   \
mostrarNomeAsteroide=''   \
mostrarNomePlaneta='1'   \
mostrarNomePlanetaAnao='1'   \
mostrarNomeTNO=''   \
mostrarNomeCometa=''   \
\
segundosOrbitaMaxima='120'   \
corDeFundo='rgb(0,0,50)'    \


