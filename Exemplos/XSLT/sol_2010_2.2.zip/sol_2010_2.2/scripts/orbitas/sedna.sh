OUTPUT='orbitas/sedna.svg';
STYLE='sol_orbitas_svg_2.xsl';
INPUT='sol_2010.2.2.xml';

java -cp ../saxon/saxon9he.jar net.sf.saxon.Transform -t \
		  -s:../../data/$INPUT  \
		  -xsl:../../xsl/$STYLE \
          -o:../../results/$OUTPUT \
          \
          \
titulo="Órbita de Sedna e objetos distantes" \
planeta='1' 					\
planetaAnao='1' 			 \
asteroide='1'				 \
objeto='1'					 \
minDiametro='100'			\
minOrbita='100'   \
maxOrbita='100000'  \
segundosOrbitaMaxima='180'   \
corDeFundo='rgb(0,0,50)'    \
maisX='-600'  \
maisY='200'  \
escala='0.9'  \


