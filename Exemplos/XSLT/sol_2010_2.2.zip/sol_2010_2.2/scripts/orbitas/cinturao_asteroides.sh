OUTPUT='orbitas/cinturao_asteroides.svg';
STYLE='sol_orbitas_svg_2.xsl';
INPUT='sol_2010.2.2.xml';

java -cp ../saxon/saxon9he.jar net.sf.saxon.Transform -t \
		  -s:../../data/$INPUT  \
		  -xsl:../../xsl/$STYLE \
          -o:../../results/$OUTPUT \
          \
titulo="Cinturão de Asteróides" \
planeta='1' 					\
planetaAnao='1' 			 \
asteroide='1'				 \
tno=''					 \
cometa='1'  \
minDiametro='10'			\
maxOrbita='6'				\
fonteAlternativa='corbel' \
destaque='Terra' \
textoLegendaDestaque='Terra' \
mostrarNomeAsteroide=''  \
mostrarNomeCometa=''  \
linhaAsteroide='0.0'  \
linhaCometa='0.0'  \
linhaPlanetaAnao='2'  \
linhaPlaneta='1'  \
circuloAsteroide='1'  \
circuloCometa='1'  \
segundosOrbitaMaxima='240'  \