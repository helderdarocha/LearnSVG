OUTPUT='orbitas/orbitaTerra.svg';
STYLE='sol_orbitas_svg_2.xsl';
INPUT='sol_2010.2.2.xml';

java -cp ../saxon/saxon9he.jar net.sf.saxon.Transform -t \
		  -s:../../data/$INPUT  \
		  -xsl:../../xsl/$STYLE \
          -o:../../results/$OUTPUT \
          \
titulo="Órbitas próximas à Terra" \
planeta='1' 					\
planetaAnao='1' 			 \
asteroide='1'				 \
tno='1'					 \
cometa='1'              \
centauro='1'            \
\
minDiametro='0'			\
minOrbita='0'   \
maxOrbita='10'   \
escala='1.5'    \
maisX='-450'   \
maisY='-150'    \
tamFonte="10"     \
brilhoSol='1'    \
\
linhaCentauro='0.2'   \
linhaAsteroide='0.2'   \
linhaPlaneta='1'   \
linhaPlanetaAnao='1'   \
linhaTNO='0.5'   \
linhaCometa='0.2'   \
\
circuloCentauro='1'  \
circuloAsteroide='1'  \
circuloPlaneta='2'  \
circuloPlanetaAnao='2'  \
circuloTNO='1'  \
circuloCometa='1'  \
\
mostrarNomeCentauro=''   \
mostrarNomeAsteroide=''   \
mostrarNomePlaneta='1'   \
mostrarNomePlanetaAnao='1'   \
mostrarNomeTNO=''   \
mostrarNomeCometa=''   \
\
segundosOrbitaMaxima='240'   \
corDeFundo='rgb(0,0,50)'    \


