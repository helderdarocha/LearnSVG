OUTPUT='orbitas/cometas.svg';
STYLE='sol_orbitas_svg_2.xsl';
INPUT='sol_2010.2.2.xml';

java -cp ../saxon/saxon9he.jar net.sf.saxon.Transform -t \
		  -s:../../data/$INPUT  \
		  -xsl:../../xsl/$STYLE \
          -o:../../results/$OUTPUT \
          \
          \
titulo="Cometas" \
planeta='1' 					\
planetaAnao='1' 			 \
asteroide=''				 \
tno=''					 \
cometa='1'					 \
centauro=''  \
minDiametro='0'			\
minOrbita='10'   \
maxOrbita='100000'  \
segundosOrbitaMaxima='180'   \
corDeFundo='rgb(0,0,50)'    \
maisX='-650'  \
maisY='-150'  \
escala='2.0'  \
tamFonte='8' \
circuloPlaneta='1'  \
circuloPlanetaAnao='1' \
circuloCometa='1' \
brilhoSol='1'    \


