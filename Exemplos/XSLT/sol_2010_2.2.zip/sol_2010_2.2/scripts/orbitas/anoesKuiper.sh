OUTPUT='orbitas/anoesKuiper.svg';
STYLE='sol_orbitas_svg_2.xsl';
INPUT='sol_2010.2.2.xml';

java -cp ../saxon/saxon9he.jar net.sf.saxon.Transform -t \
		  -s:../../data/$INPUT  \
		  -xsl:../../xsl/$STYLE \
          -o:../../results/$OUTPUT \
          \
titulo="Sistema solar: candidatos a plutóide" \
planeta='1' 					\
planetaAnao='1' 			 \
asteroide='1'				 \
tno='1'					 \
cometa='1'              \
centauro='1'            \
\
minDiametro='1000'			\
minOrbita='25'   \
maxOrbita='500'   \
escala='1'    \
maisX='-400'   \
maisY='0'    \
tamFonte="10"     \
brilhoSol='1'    \
\
linhaCentauro='0.5'   \
linhaAsteroide='0.5'   \
linhaPlaneta='0.5'   \
linhaPlanetaAnao='.5'   \
linhaTNO='0.5'   \
linhaCometa='0.5'   \
\
circuloCentauro='0.5'  \
circuloAsteroide='0.5'  \
circuloPlaneta='1'  \
circuloPlanetaAnao='1'  \
circuloTNO='0.5'  \
circuloCometa='0.5'  \
\
mostrarNomeCentauro=''   \
mostrarNomeAsteroide=''   \
mostrarNomePlaneta='1'   \
mostrarNomePlanetaAnao='1'   \
mostrarNomeTNO='1'   \
mostrarNomeCometa=''   \
\
segundosOrbitaMaxima='240'   \
corDeFundo='rgb(0,0,50)'    \



