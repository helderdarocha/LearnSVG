OUTPUT='torta/massas.svg';
STYLE='sol_torta_massas_svg_2.xsl';
INPUT='sol_2010.2.2.xml';

java -cp ../saxon/saxon9he.jar net.sf.saxon.Transform -t \
		  -s:../../data/$INPUT  \
		  -xsl:../../xsl/$STYLE \
          -o:../../results/$OUTPUT \
          \
titulo="Massas estimadas de planetas e satélites" \
subtitulo=''  \
planeta='1' 					\
estrela='' 					\
planetaAnao='1' 			 \
asteroide=''				 \
satelitePlaneta='1' 			\
satelitePlanetaAnao='1' 	 \
sateliteAsteroide='' 		 \
sateliteObjeto='' 			 \
maxMassaGM='150000000000'			\
minMassaGM='0'			\
fonteAlternativa='corbel' \


