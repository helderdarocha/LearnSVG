OUTPUT='torta/objetos.svg';
STYLE='sol_torta_svg_2.xsl';
INPUT='sol_2010.2.2.xml';

java -cp ../saxon/saxon9he.jar net.sf.saxon.Transform -t \
		  -s:../../data/$INPUT  \
		  -xsl:../../xsl/$STYLE \
          -o:../../results/$OUTPUT \
          \
titulo="Diâmetros de objetos do Sistema Solar" \
subtitulo=' '  \
planeta='1' 					\
estrela='' 					\
planetaAnao='1' 			 \
asteroide='1'				 \
satelitePlaneta='1' 			\
satelitePlanetaAnao='1' 	 \
sateliteAsteroide='1' 		 \
sateliteObjeto='1' 			 \
minDiametro='0'			\
percentMenorFatia='0.5'   \
maisX='50'   \
maisY='80'   \
escala='0.9'  \
fonteAlternativa='corbel' \


