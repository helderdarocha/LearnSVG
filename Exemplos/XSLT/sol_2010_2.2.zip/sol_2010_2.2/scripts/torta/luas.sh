OUTPUT='torta/luas.svg';
STYLE='sol_torta_svg_2.xsl';
INPUT='sol_2010.2.2.xml';

java -cp ../saxon/saxon9he.jar net.sf.saxon.Transform -t \
		  -s:../../data/$INPUT  \
		  -xsl:../../xsl/$STYLE \
          -o:../../results/$OUTPUT \
          \
titulo="Diâmetros de luas maiores que 500km" \
subtitulo=' '  \
planeta='' 					\
estrela='' 					\
planetaAnao='' 			 \
asteroide=''				 \
satelitePlaneta='1' 			\
satelitePlanetaAnao='1' 	 \
sateliteAsteroide='' 		 \
sateliteObjeto='' 			 \
maxDiametro='15000'			\
minDiametro='500'			\
maisX='50'   \
maisY='80'   \
escala='0.9'
fonteAlternativa='corbel' \


