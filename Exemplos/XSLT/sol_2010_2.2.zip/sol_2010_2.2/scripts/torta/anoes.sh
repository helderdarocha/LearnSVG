OUTPUT='torta/anoes.svg';
STYLE='sol_torta_svg_2.xsl';
INPUT='sol_2010.2.2.xml';

java -cp ../saxon/saxon9he.jar net.sf.saxon.Transform -t \
		  -s:../../data/$INPUT  \
		  -xsl:../../xsl/$STYLE \
          -o:../../results/$OUTPUT \
          \
titulo="Diâmetros estimados de planetas anão" \
subtitulo=' '  \
planeta='' 					\
estrela='' 					\
planetaAnao='1' 			 \
asteroide=''				 \
satelitePlaneta='' 			\
satelitePlanetaAnao='' 	 \
sateliteAsteroide='' 		 \
sateliteObjeto='' 			 \
maxDiametro='15000'			\
minDiametro='0'			\
fonteAlternativa='corbel' \


