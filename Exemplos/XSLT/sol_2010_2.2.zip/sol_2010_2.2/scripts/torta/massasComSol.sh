OUTPUT='torta/massasComSol.svg';
STYLE='sol_torta_massas_svg_2.xsl';
INPUT='sol_2010.2.2.xml';

java -cp ../saxon/saxon9he.jar net.sf.saxon.Transform -t \
		  -s:../../data/$INPUT  \
		  -xsl:../../xsl/$STYLE \
          -o:../../results/$OUTPUT \
          \
titulo="Massas de planetas e satélites comparados ao Sol" \
subtitulo=''  \
planeta='1' 					\
estrela='1' 					\
planetaAnao='1' 			 \
asteroide=''				 \
satelitePlaneta='1' 			\
satelitePlanetaAnao='1' 	 \
sateliteAsteroide='' 		 \
sateliteObjeto='' 			 \
minMassaGM='0'			\
fonteAlternativa='corbel' \


