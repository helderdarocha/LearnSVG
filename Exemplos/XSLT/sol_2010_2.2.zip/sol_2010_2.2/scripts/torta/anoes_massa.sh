OUTPUT='torta/anoes_massa.svg';
STYLE='sol_torta_massas_svg_2.xsl';
INPUT='sol_2010.2.2.xml';

java -cp ../saxon/saxon9he.jar net.sf.saxon.Transform -t \
		  -s:../../data/$INPUT  \
		  -xsl:../../xsl/$STYLE \
          -o:../../results/$OUTPUT \
          \
titulo="Massas estimadas de planetas anão" \
subtitulo=''  \
planeta='' 					\
estrela='' 					\
planetaAnao='1' 			 \
asteroide=''				 \
satelitePlaneta='' 			\
satelitePlanetaAnao='' 	 \
sateliteAsteroide='' 		 \
sateliteObjeto='' 			 \
maxMassaGM='15000'			\
minMassaGM='0'			\
fonteAlternativa='corbel' \


